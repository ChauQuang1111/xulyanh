import cv2
import numpy as np
import matplotlib.pyplot as plt

# Đọc ảnh
image = cv2.imread("C:\\Users\\Admin\\Downloads\\gradientT.jpeg")
image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

# Reshape ảnh thành một mảng 2D (mỗi hàng là một pixel, mỗi cột là một kênh màu)
pixels = image.reshape((-1, 3))

# Chuyển đổi kiểu dữ liệu của pixels thành float32
pixels = np.float32(pixels)

# Định nghĩa số cụm (clusters)
num_clusters = 3

# Định nghĩa các điểm dữ liệu ban đầu cho việc khởi tạo các centroids
criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 0.2)

# Chạy thuật toán K-Means
_, labels, centers = cv2.kmeans(pixels, num_clusters, None, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)

# Chuyển đổi các giá trị pixel về kiểu dữ liệu uint8
centers = np.uint8(centers)

# Lấy kết quả cuối cùng bằng cách gán mỗi pixel với centroid gần nhất
segmented_image = centers[labels.flatten()]
segmented_image = segmented_image.reshape(image.shape)

# Hiển thị ảnh gốc và kết quả phân đoạn
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 6))

ax1.imshow(image)
ax1.set_title('Original Image')
ax1.axis('off')

ax2.imshow(segmented_image)
ax2.set_title('Clustering-based Segmentation (K-Means)')
ax2.axis('off')

plt.show()
