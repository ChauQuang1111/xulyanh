import cv2
import numpy as np

# Đọc ảnh từ file
image = cv2.imread("C:\\Users\\Admin\\Downloads\\gradientT.jpeg", cv2.IMREAD_GRAYSCALE)

# Kiểm tra nếu ảnh được nạp đúng
if image is None:
    print("Không thể đọc được ảnh")
else:
    # Đặt giá trị ngưỡng
    threshold_value = 127  # Bạn có thể điều chỉnh giá trị này

    # Thực hiện phân đoạn bằng ngưỡng
    _, binary_image = cv2.threshold(image, threshold_value, 255, cv2.THRESH_BINARY)

    # Hiển thị ảnh gốc và ảnh nhị phân
    cv2.imshow('Original Image', image)
    cv2.imshow('Binary Image', binary_image)

    # Chờ nhấn phím bất kỳ để đóng các cửa sổ
    cv2.waitKey(0)
    cv2.destroyAllWindows()
