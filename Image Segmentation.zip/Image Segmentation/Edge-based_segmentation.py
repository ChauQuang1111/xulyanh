import cv2
import numpy as np
import matplotlib.pyplot as plt

# Đọc ảnh
image = cv2.imread("C:\\Users\\Admin\\Downloads\\gradientT.jpeg")
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Áp dụng phát hiện biên cạnh Canny
edges = cv2.Canny(gray, 100, 200)

# Hiển thị ảnh gốc và kết quả phân đoạn
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 6))

ax1.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
ax1.set_title('Original Image')
ax1.axis('off')

ax2.imshow(edges, cmap='gray')
ax2.set_title('Edge-based Segmentation (Canny)')
ax2.axis('off')

plt.show()
