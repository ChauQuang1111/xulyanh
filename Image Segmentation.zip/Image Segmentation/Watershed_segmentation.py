import numpy as np
import cv2 as cv
from matplotlib import pyplot as plt

# Đọc ảnh từ đường dẫn
img = cv.imread("C:\\Users\\Admin\\Downloads\\water_coins.jpg")
assert img is not None, "file could not be read, check with os.path.exists()"

# Chuyển ảnh sang ảnh xám
gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)

# Áp dụng phân đoạn với ngưỡng tự động OTSU
ret, thresh = cv.threshold(gray, 0, 255, cv.THRESH_BINARY_INV + cv.THRESH_OTSU)

# Loại bỏ nhiễu
kernel = np.ones((3,3), np.uint8)
opening = cv.morphologyEx(thresh, cv.MORPH_OPEN, kernel, iterations=2)

# Xác định khu vực nền chắc chắn
sure_bg = cv.dilate(opening, kernel, iterations=3)

# Tìm khu vực chắc chắn của đối tượng
dist_transform = cv.distanceTransform(opening, cv.DIST_L2, 5)
ret, sure_fg = cv.threshold(dist_transform, 0.7 * dist_transform.max(), 255, 0)

# Xác định vùng không xác định
sure_fg = np.uint8(sure_fg)
unknown = cv.subtract(sure_bg, sure_fg)

# Đánh dấu
ret, markers = cv.connectedComponents(sure_fg)
markers = markers + 1
markers[unknown == 255] = 0

# Watershed và vẽ đường biên
markers = cv.watershed(img, markers)
img[markers == -1] = [255, 0, 0]

# Tạo grid subplot và hiển thị ảnh qua từng giai đoạn xử lí
plt.figure(figsize=(10, 8))

plt.subplot(331), plt.imshow(markers, cmap='gray'), plt.title('Segmented Image')
plt.subplot(332), plt.imshow(thresh, cmap='gray'), plt.title('Thresholded Image')
plt.subplot(333), plt.imshow(opening, cmap='gray'), plt.title('Opened Image')
plt.subplot(334), plt.imshow(sure_bg, cmap='gray'), plt.title('Sure Background')
plt.subplot(335), plt.imshow(sure_fg, cmap='gray'), plt.title('Sure Foreground')
plt.subplot(336), plt.imshow(unknown, cmap='gray'), plt.title('Unknown Regions')
plt.subplot(338), plt.imshow(cv.cvtColor(img, cv.COLOR_BGR2RGB)), plt.title('Result')

plt.tight_layout()
plt.show()
