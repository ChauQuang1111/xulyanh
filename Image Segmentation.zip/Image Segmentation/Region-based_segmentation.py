import cv2
import numpy as np
import matplotlib.pyplot as plt

# Đọc ảnh và chuyển đổi sang ảnh xám
image = cv2.imread("C:\\Users\\Admin\\Downloads\\gradientT.jpeg")
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Tính toán bản đồ độ cao bằng bộ lọc Sobel
sobelx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
sobely = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
elevation_map = np.hypot(sobelx, sobely)

# Tạo markers
markers = np.zeros_like(gray)
markers[gray < 30] = 1
markers[gray > 150] = 2

# Áp dụng thuật toán Watershed
markers = cv2.watershed(cv2.cvtColor(image, cv2.COLOR_BGR2RGB), markers.astype(np.int32))

# Lấp đầy các lỗ và gán nhãn
_, markers = cv2.connectedComponents(np.uint8(markers))

# Tạo ảnh marker
markers = np.zeros_like(gray)
markers[gray < 30] = 1
markers[gray > 150] = 2

# Hiển thị kết quả phân đoạn
segmentation = markers.astype(np.uint8)
segmentation = cv2.normalize(segmentation, None, 0, 255, cv2.NORM_MINMAX)
segmentation = cv2.applyColorMap(segmentation, cv2.COLORMAP_JET) 



# Hiển thị ảnh gốc, ảnh bản đồ độ cao, ảnh phân đoạn và ảnh marker
fig, (ax1, ax2, ax3, ax4) = plt.subplots(1, 4, figsize=(24, 16))

ax1.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
ax1.set_title('Original Image')
ax1.axis('off')

ax2.imshow(elevation_map, cmap='gray')
ax2.set_title('Elevation Map')
ax2.axis('off')

ax3.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
ax3.imshow(markers, cmap='gray')  # Hiển thị marker trên ảnh gốc
ax3.set_title('Markers')
ax3.axis('off')

ax4.imshow(segmentation)
ax4.set_title('Watershed Segmentation')
ax4.axis('off')



plt.show()
