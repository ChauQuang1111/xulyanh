import cv2
img = cv2.imread('cat5.jpg')
cat_cascade = cv2.CascadeClassifier('haarcascade_frontalcatface_extended.xml')

catImg = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
cats = cat_cascade.detectMultiScale(catImg)
for(x,y,w,h) in cats:
    img = cv2.rectangle(img, (x, y), (x+w, y+h), (0, 128, 0), 3)
    cv2.putText(img, 'Cat', (x, y), cv2.FONT_HERSHEY_SIMPLEX, 2, (255, 255, 255))


cv2.imshow('meo', img)
cv2.waitKey(0)
cv2.destroyWindow()