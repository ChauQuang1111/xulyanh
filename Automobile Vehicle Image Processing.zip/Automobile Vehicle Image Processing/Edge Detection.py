import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load the vehicle image in grayscale
image = cv2.imread('img_1.png', 0)  # Use a path to a vehicle image

# Apply Sobel operator to detect edges
sobel_x = cv2.Sobel(image, cv2.CV_64F, 1, 0, ksize=3)  # Sobel in X direction
sobel_y = cv2.Sobel(image, cv2.CV_64F, 0, 1, ksize=3)  # Sobel in Y direction
sobel_edges = cv2.magnitude(sobel_x, sobel_y)  # Combine both directions

# Apply Canny edge detector
canny_edges = cv2.Canny(image, 100, 200)

# Display the original and edge-detected images
plt.figure(figsize=(15, 5))

plt.subplot(131), plt.imshow(image, cmap='gray'), plt.title('Original Image')
plt.subplot(132), plt.imshow(sobel_edges, cmap='gray'), plt.title('Sobel Edge Detection')
plt.subplot(133), plt.imshow(canny_edges, cmap='gray'), plt.title('Canny Edge Detection')

plt.show()
