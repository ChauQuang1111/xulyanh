import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load the vehicle image in grayscale
image = cv2.imread('img_2.png', 0)  # Use a path to a vehicle image

# Apply Global Thresholding
_, thresh_global = cv2.threshold(image, 130, 255, cv2.THRESH_BINARY)

# Apply Adaptive Thresholding
thresh_adaptive = cv2.adaptiveThreshold(image, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                        cv2.THRESH_BINARY, 11, 2)

# Display the original and thresholded images
plt.figure(figsize=(10, 8))

plt.subplot(131), plt.imshow(image, cmap='gray'), plt.title('Original Image')
plt.subplot(132), plt.imshow(thresh_global, cmap='gray'), plt.title('Global Thresholding')
plt.subplot(133), plt.imshow(thresh_adaptive, cmap='gray'), plt.title('Adaptive Thresholding')

plt.show()
