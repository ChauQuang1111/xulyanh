import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load image
image = cv2.imread('img_1.png', 0)  # Load in grayscale

# Identify discontinuous regions
edges = cv2.Canny(image, 100, 200)

# Display result
plt.figure(figsize=(10, 5))
plt.subplot(121), plt.imshow(image, cmap='gray'), plt.title('Original Image')
plt.subplot(122), plt.imshow(edges, cmap='gray'), plt.title('Discontinuous Regions')
plt.show()
