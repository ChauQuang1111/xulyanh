import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load the vehicle image
image = cv2.imread('img_2.png')
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Apply Region Growing (example using a simple threshold-based region growing)
def region_growing(img, seed, threshold=10):
    height, width = img.shape
    segmented = np.zeros_like(img)
    stack = [seed]
    while stack:
        x, y = stack.pop()
        if segmented[x, y] == 0:
            segmented[x, y] = 255
            for dx in [-1, 0, 1]:
                for dy in [-1, 0, 1]:
                    if 0 <= x + dx < height and 0 <= y + dy < width:
                        if abs(int(img[x, y]) - int(img[x + dx, y + dy])) < threshold:
                            stack.append((x + dx, y + dy))
    return segmented

seed_point = (70, 100)  # Example seed point, needs to be adjusted based on the image
segmented_region_growing = region_growing(gray, seed_point)

# Apply Split-and-Merge (placeholder for actual implementation)
def split_and_merge(img):
    # Placeholder function for split and merge
    return img  # This function should be implemented with quadtree split and similarity-based merge

segmented_split_and_merge = split_and_merge(gray)

# Display the original and segmented images
plt.figure(figsize=(15, 5))

plt.subplot(131), plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB)), plt.title('Original Image')
plt.subplot(132), plt.imshow(segmented_region_growing, cmap='gray'), plt.title('Region Growing')
plt.subplot(133), plt.imshow(segmented_split_and_merge, cmap='gray'), plt.title('Split and Merge')

plt.show()
