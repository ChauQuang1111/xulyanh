import cv2
import matplotlib.pyplot as plt

# Đường dẫn đến ảnh màu
image_path = 'jenni.jpg'

# Đọc ảnh màu
image_color = cv2.imread(image_path)

# Chuyển đổi ảnh màu sang ảnh xám
image_gray = cv2.cvtColor(image_color, cv2.COLOR_BGR2GRAY)

# Hiển thị ảnh màu gốc và ảnh xám
plt.figure(figsize=(10, 5))

plt.subplot(1, 2, 1)
plt.imshow(cv2.cvtColor(image_color, cv2.COLOR_BGR2RGB))
plt.title('Ảnh màu gốc')
plt.axis('off')

plt.subplot(1, 2, 2)
plt.imshow(image_gray, cmap='gray')
plt.title('Ảnh xám')
plt.axis('off')

plt.show()
