import cv2
import numpy as np
import matplotlib.pyplot as plt


# Đọc ảnh xám
image_gray = cv2.imread('jenni.jpg', cv2.IMREAD_GRAYSCALE)

# Tăng độ tương phản
alpha = 1.5  # Thay đổi giá trị alpha tùy thuộc vào mức độ tương phản mong muốn
enhanced_contrast = np.clip(alpha * image_gray, 0, 255).astype(np.uint8)

# Sắc nét hóa ảnh
sharpening_filter = np.array([[-1, -1, -1],
                               [-1,  9, -1],
                               [-1, -1, -1]])
sharpened_image = cv2.filter2D(image_gray, -1, sharpening_filter)

# Hiển thị ảnh trước và sau khi áp dụng các kỹ thuật
plt.figure(figsize=(10, 8))

plt.subplot(2, 2, 1)
plt.imshow(image_gray, cmap='gray')
plt.title('Ảnh trước')

plt.subplot(2, 2, 2)
plt.imshow(enhanced_contrast, cmap='gray')
plt.title('Sau khi tăng độ tương phản')

plt.subplot(2, 2, 3)
plt.imshow(image_gray, cmap='gray')
plt.title('Ảnh trước')

plt.subplot(2, 2, 4)
plt.imshow(sharpened_image, cmap='gray')
plt.title('Sau khi sắc nét hóa')

plt.tight_layout()
plt.show()
