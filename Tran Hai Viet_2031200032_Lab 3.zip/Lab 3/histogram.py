import cv2
import numpy as np
import matplotlib.pyplot as plt
from ipywidgets import interact, IntSlider


def plot_histogram(image):
    histogram = cv2.calcHist([image], [0], None, [256], [0, 256])
    plt.plot(histogram)
    plt.title('Histogram')
    plt.xlabel('Pixel Value')
    plt.ylabel('Frequency')
    plt.show()


def histogram_equalization(image):
    equ = cv2.equalizeHist(image)
    return equ


def show_histogram_equalization(image):
    def update(equalization_factor):
        equ = cv2.equalizeHist(image)
        result = cv2.addWeighted(image, 1 - equalization_factor, equ, equalization_factor, 0)
        plt.imshow(result, cmap='gray')
        plt.axis('off')
        plt.show()

    interact(update, equalization_factor=IntSlider(min=0, max=100, step=1, value=50))


# Đọc ảnh xám
image = cv2.imread('jenni.jpg', cv2.IMREAD_GRAYSCALE)

# Vẽ histogram của ảnh
plot_histogram(image)

# Áp dụng cân bằng histogram và hiển thị plot cho phép điều chỉnh equalization
show_histogram_equalization(image)
