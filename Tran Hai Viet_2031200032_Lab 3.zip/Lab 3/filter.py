import cv2
import numpy as np
import matplotlib.pyplot as plt

# Đọc ảnh xám
image_gray = cv2.imread('jenni.jpg', cv2.IMREAD_GRAYSCALE)

# Tăng độ tương phản
alpha = 1.5
enhanced_contrast = np.clip(alpha * image_gray, 0, 255).astype(np.uint8)

# Áp dụng các bộ lọc
kernel_size = 5

# Bộ lọc trung bình
mean_filtered = cv2.blur(enhanced_contrast, (kernel_size, kernel_size))

# Bộ lọc Gaussian
gaussian_filtered = cv2.GaussianBlur(enhanced_contrast, (kernel_size, kernel_size), 0)

# Bộ lọc trung vị
median_filtered = cv2.medianBlur(enhanced_contrast, kernel_size)

# Hiển thị và phân tích ảnh trước và sau khi áp dụng các bộ lọc
plt.figure(figsize=(12, 10))

plt.subplot(2, 3, 1)
plt.imshow(image_gray, cmap='gray')
plt.title('Ảnh gốc')

plt.subplot(2, 3, 2)
plt.imshow(enhanced_contrast, cmap='gray')
plt.title('Ảnh sau khi tăng độ tương phản')

plt.subplot(2, 3, 3)
plt.imshow(mean_filtered, cmap='gray')
plt.title('Bộ lọc trung bình')

plt.subplot(2, 3, 4)
plt.imshow(gaussian_filtered, cmap='gray')
plt.title('Bộ lọc Gaussian')

plt.subplot(2, 3, 5)
plt.imshow(median_filtered, cmap='gray')
plt.title('Bộ lọc trung vị')

plt.tight_layout()
plt.show()
