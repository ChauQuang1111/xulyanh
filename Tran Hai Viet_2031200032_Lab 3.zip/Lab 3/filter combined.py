import cv2
import numpy as np
import matplotlib.pyplot as plt

# Đọc ảnh xám
image_gray = cv2.imread('jenni.jpg', cv2.IMREAD_GRAYSCALE)

# Tăng độ tương phản
alpha = 1.5
enhanced_contrast = np.clip(alpha * image_gray, 0, 255).astype(np.uint8)

# Áp dụng các bộ lọc
kernel_size = 5

# Bộ lọc trung bình
mean_filtered = cv2.blur(enhanced_contrast, (kernel_size, kernel_size))

# Bộ lọc Gaussian
gaussian_filtered = cv2.GaussianBlur(enhanced_contrast, (kernel_size, kernel_size), 0)

# Hiển thị và so sánh ảnh trước và sau khi áp dụng các bộ lọc
plt.figure(figsize=(12, 8))

plt.subplot(2, 3, 1)
plt.imshow(enhanced_contrast, cmap='gray')
plt.title('Ảnh sau khi tăng độ tương phản')

plt.subplot(2, 3, 2)
plt.imshow(mean_filtered, cmap='gray')
plt.title('Bộ lọc trung bình')

plt.subplot(2, 3, 3)
plt.imshow(gaussian_filtered, cmap='gray')
plt.title('Bộ lọc Gaussian')

plt.subplot(2, 3, 4)
plt.imshow(image_gray, cmap='gray')
plt.title('Ảnh xám gốc')

plt.subplot(2, 3, 5)
plt.imshow(mean_filtered - image_gray, cmap='gray')
plt.title('Sự khác biệt - Bộ lọc trung bình')

plt.subplot(2, 3, 6)
plt.imshow(gaussian_filtered - image_gray, cmap='gray')
plt.title('Sự khác biệt - Bộ lọc Gaussian')


plt.tight_layout()
plt.show()
